// Simplified Sweden silhouette as an SVG path defined in lon/lat space,
// then projected the same way as the data points so they align.
// Coordinates are approximate (stylized outline, not survey-grade).

import { SWEDEN_BOUNDS } from "./data";

// Equirectangular projection into a square-ish viewBox.
// We scale longitude by cos(midLat) so Sweden doesn't look too wide.
const midLat = (SWEDEN_BOUNDS.minLat + SWEDEN_BOUNDS.maxLat) / 2;
const lonScale = Math.cos((midLat * Math.PI) / 180);

export const VIEW_W = 460;
export const VIEW_H = 760;

const lonSpan = (SWEDEN_BOUNDS.maxLon - SWEDEN_BOUNDS.minLon) * lonScale;
const latSpan = SWEDEN_BOUNDS.maxLat - SWEDEN_BOUNDS.minLat;

const pad = 24;

export function project(lon: number, lat: number): { x: number; y: number } {
  const nx = ((lon - SWEDEN_BOUNDS.minLon) * lonScale) / lonSpan;
  const ny = (lat - SWEDEN_BOUNDS.minLat) / latSpan;
  const x = pad + nx * (VIEW_W - pad * 2);
  const y = VIEW_H - pad - ny * (VIEW_H - pad * 2); // invert: north up
  return { x, y };
}

// Outline points [lon, lat] tracing Sweden roughly clockwise from the south.
const OUTLINE: [number, number][] = [
  [12.9, 55.4], // south of Skåne
  [14.3, 55.4],
  [16.0, 56.2], // SE coast Kalmar
  [16.8, 57.4],
  [16.6, 58.6],
  [17.9, 59.3], // Stockholm coast
  [18.9, 60.0],
  [17.6, 60.7],
  [17.4, 61.7], // Gävle/Hälsingland
  [17.4, 62.5], // Sundsvall
  [18.6, 63.2],
  [19.6, 63.5], // Umeå region
  [21.0, 64.0],
  [22.3, 65.3], // Luleå
  [23.8, 66.0], // far NE
  [23.6, 67.5],
  [23.0, 68.4],
  [20.8, 69.0], // far north
  [18.5, 68.4],
  [17.4, 68.1],
  [16.0, 67.3],
  [15.3, 66.3],
  [14.5, 65.3],
  [13.8, 64.2], // NW border
  [12.2, 63.0],
  [12.2, 61.6],
  [12.8, 61.0],
  [12.5, 60.0],
  [11.7, 59.1], // SW border toward Norway
  [11.4, 58.4],
  [11.2, 58.0], // Bohuslän
  [11.9, 57.7], // Göteborg
  [12.3, 56.9],
  [12.5, 56.2],
  [12.9, 55.4], // close
];

export function swedenPath(): string {
  return (
    OUTLINE.map(([lon, lat], i) => {
      const { x, y } = project(lon, lat);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ") + " Z"
  );
}

// Gotland & Öland as small blobs
export function islandPaths(): string[] {
  const gotland = project(18.5, 57.5);
  const oland = project(16.7, 56.7);
  const circle = (cx: number, cy: number, rx: number, ry: number) =>
    `M${cx},${cy - ry} a${rx},${ry} 0 1,0 0.1,0 Z`;
  return [circle(gotland.x, gotland.y, 8, 16), circle(oland.x + 6, oland.y, 4, 14)];
}
