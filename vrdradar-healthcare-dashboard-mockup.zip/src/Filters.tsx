import { REGIONS, SPECIALTIES } from "./data";

export interface FilterState {
  regions: Set<string>;
  specialties: Set<string>;
  minWaitDays: number;
  minCost: number; // SEK/month
  showTurbulence: boolean;
  turbulenceOnly: boolean;
}

interface Props {
  filters: FilterState;
  setFilters: (f: FilterState) => void;
  costMode: boolean;
  maxCost: number;
}

export default function Filters({ filters, setFilters, maxCost }: Props) {
  const toggleSet = (key: "regions" | "specialties", val: string) => {
    const next = new Set(filters[key]);
    if (next.has(val)) next.delete(val);
    else next.add(val);
    setFilters({ ...filters, [key]: next });
  };

  return (
    <div className="glass flex h-full flex-col overflow-hidden rounded-xl">
      <div className="border-b border-white/5 px-4 py-3">
        <h3 className="text-xs font-bold uppercase tracking-widest text-cyan-400">Flight Filters</h3>
      </div>
      <div className="flex-1 space-y-4 overflow-y-auto px-4 py-3">
        {/* Turbulence */}
        <div className="space-y-2 rounded-lg border border-red-500/20 bg-red-500/5 p-3">
          <ToggleRow
            label="Show turbulence zones"
            sub="Bottlenecks ≥150% of vårdgaranti"
            checked={filters.showTurbulence}
            color="#ff4d5e"
            onChange={(v) => setFilters({ ...filters, showTurbulence: v })}
          />
          <ToggleRow
            label="Turbulence only"
            sub="Filter radar to critical zones"
            checked={filters.turbulenceOnly}
            color="#ff4d5e"
            onChange={(v) => setFilters({ ...filters, turbulenceOnly: v })}
          />
        </div>

        {/* wait threshold */}
        <div>
          <SliderLabel label="Min wait time" value={`${filters.minWaitDays} days`} />
          <input
            type="range"
            min={0}
            max={365}
            step={5}
            value={filters.minWaitDays}
            onChange={(e) => setFilters({ ...filters, minWaitDays: +e.target.value })}
            className="scrubber w-full"
          />
        </div>

        {/* cost threshold */}
        <div>
          <SliderLabel
            label="Min cost impact"
            value={`${(filters.minCost / 1e6).toFixed(1)}M SEK/mo`}
          />
          <input
            type="range"
            min={0}
            max={maxCost}
            step={maxCost / 50}
            value={filters.minCost}
            onChange={(e) => setFilters({ ...filters, minCost: +e.target.value })}
            className="scrubber w-full"
          />
        </div>

        {/* regions */}
        <FilterGroup
          title="Region"
          items={REGIONS}
          selected={filters.regions}
          onToggle={(v) => toggleSet("regions", v)}
        />

        {/* specialties */}
        <FilterGroup
          title="Specialty"
          items={SPECIALTIES}
          selected={filters.specialties}
          onToggle={(v) => toggleSet("specialties", v)}
        />
      </div>

      <div className="border-t border-white/5 px-4 py-2.5">
        <button
          onClick={() =>
            setFilters({
              regions: new Set(),
              specialties: new Set(),
              minWaitDays: 0,
              minCost: 0,
              showTurbulence: filters.showTurbulence,
              turbulenceOnly: false,
            })
          }
          className="w-full rounded-md border border-white/10 py-1.5 text-xs text-slate-300 transition hover:border-cyan-400/50 hover:text-cyan-300"
        >
          Reset filters
        </button>
      </div>
    </div>
  );
}

function SliderLabel({ label, value }: { label: string; value: string }) {
  return (
    <div className="mb-1.5 flex items-center justify-between">
      <span className="text-[11px] uppercase tracking-wide text-slate-400">{label}</span>
      <span className="mono text-xs text-cyan-300">{value}</span>
    </div>
  );
}

function ToggleRow({
  label,
  sub,
  checked,
  onChange,
  color,
}: {
  label: string;
  sub: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  color: string;
}) {
  return (
    <button onClick={() => onChange(!checked)} className="flex w-full items-center justify-between text-left">
      <div>
        <div className="text-xs font-semibold text-slate-200">{label}</div>
        <div className="text-[10px] text-slate-500">{sub}</div>
      </div>
      <span
        className="relative h-4 w-8 flex-shrink-0 rounded-full transition"
        style={{ background: checked ? color : "rgba(255,255,255,0.12)" }}
      >
        <span
          className="absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all"
          style={{ left: checked ? "18px" : "2px" }}
        />
      </span>
    </button>
  );
}

function FilterGroup({
  title,
  items,
  selected,
  onToggle,
}: {
  title: string;
  items: string[];
  selected: Set<string>;
  onToggle: (v: string) => void;
}) {
  return (
    <div>
      <div className="mb-1.5 text-[11px] uppercase tracking-wide text-slate-400">
        {title} {selected.size > 0 && <span className="text-cyan-400">({selected.size})</span>}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {items.map((it) => {
          const on = selected.has(it);
          return (
            <button
              key={it}
              onClick={() => onToggle(it)}
              className="rounded-md border px-2 py-1 text-[10px] transition"
              style={{
                borderColor: on ? "rgba(54,224,241,0.6)" : "rgba(255,255,255,0.08)",
                background: on ? "rgba(54,224,241,0.12)" : "transparent",
                color: on ? "#7fe9f5" : "#94a3b8",
              }}
            >
              {it}
            </button>
          );
        })}
      </div>
    </div>
  );
}
