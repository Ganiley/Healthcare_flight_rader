import { useEffect, useMemo, useRef, useState } from "react";
import {
  DELAYS,
  delayAtMonth,
  monthlyCost,
  guaranteeRatio,
  isTurbulence,
  fmtSEK,
  fmtNum,
  type Delay,
} from "./data";
import RadarMap from "./RadarMap";
import DataCard from "./DataCard";
import Filters, { type FilterState } from "./Filters";

const MONTH_LABELS = (() => {
  const labels: string[] = [];
  const now = new Date(2025, 11, 1); // Dec 2025 as "present"
  for (let i = 23; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    labels.push(
      d.toLocaleDateString("en-GB", { month: "short", year: "2-digit" })
    );
  }
  return labels;
})();

export default function App() {
  const [costMode, setCostMode] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [monthIndex, setMonthIndex] = useState(23);
  const [playing, setPlaying] = useState(false);
  const rafRef = useRef<number | null>(null);
  const lastTick = useRef(0);

  const [filters, setFilters] = useState<FilterState>({
    regions: new Set(),
    specialties: new Set(),
    minWaitDays: 0,
    minCost: 0,
    showTurbulence: true,
    turbulenceOnly: false,
  });

  // delays at the scrubbed month
  const timedDelays = useMemo(
    () => DELAYS.map((d) => delayAtMonth(d, monthIndex)),
    [monthIndex]
  );

  const maxCost = useMemo(
    () => Math.max(...DELAYS.map((d) => monthlyCost(d))),
    []
  );

  // Apply filters
  const visible = useMemo(() => {
    return timedDelays.filter((d) => {
      if (filters.regions.size && !filters.regions.has(d.region)) return false;
      if (filters.specialties.size && !filters.specialties.has(d.specialty)) return false;
      if (d.currentWaitDays < filters.minWaitDays) return false;
      if (monthlyCost(d) < filters.minCost) return false;
      if (filters.turbulenceOnly && !isTurbulence(d)) return false;
      return true;
    });
  }, [timedDelays, filters]);

  const selected = useMemo<Delay | null>(
    () => visible.find((d) => d.id === selectedId) ?? null,
    [visible, selectedId]
  );

  // KPI aggregates from visible set (monthly), annualized
  const totalMonthlyCost = useMemo(
    () => visible.reduce((s, d) => s + monthlyCost(d), 0),
    [visible]
  );
  const totalPatients = useMemo(
    () => visible.reduce((s, d) => s + d.patientsInQueue, 0),
    [visible]
  );
  const turbCount = useMemo(() => visible.filter(isTurbulence).length, [visible]);
  const avgRatio = useMemo(
    () =>
      visible.length
        ? visible.reduce((s, d) => s + guaranteeRatio(d), 0) / visible.length
        : 0,
    [visible]
  );

  // Animated, smoothly-counting year-to-date cost (the "cost meter")
  const ytdTarget = totalMonthlyCost * 12 * (0.4 + (monthIndex + 1) / 24 * 0.6);
  const [ytdDisplay, setYtdDisplay] = useState(ytdTarget);
  useEffect(() => {
    let raf: number;
    const animate = () => {
      setYtdDisplay((prev) => {
        const diff = ytdTarget - prev;
        if (Math.abs(diff) < ytdTarget * 0.0005) return ytdTarget;
        return prev + diff * 0.12;
      });
      raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [ytdTarget]);

  // Timeline playback
  useEffect(() => {
    if (!playing) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      return;
    }
    const step = (t: number) => {
      if (t - lastTick.current > 700) {
        lastTick.current = t;
        setMonthIndex((m) => {
          if (m >= 23) {
            setPlaying(false);
            return 23;
          }
          return m + 1;
        });
      }
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [playing]);

  const handlePlay = () => {
    if (monthIndex >= 23) setMonthIndex(0);
    setPlaying((p) => !p);
  };

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#04070d] text-slate-200">
      {/* ===== Top bar ===== */}
      <header className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-cyan-500/15 bg-black/40 px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          <div className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-cyan-400/40 bg-cyan-400/10">
            <span className="text-base">📡</span>
          </div>
          <div>
            <div className="text-sm font-bold leading-none tracking-wide text-white">
              Vård<span className="text-cyan-400">Radar</span>
            </div>
            <div className="text-[9px] uppercase tracking-[0.2em] text-slate-500">
              Healthcare Ops Center · SE
            </div>
          </div>
        </div>

        {/* KPI: total cost of delays this year */}
        <div className="glass-soft flex items-center gap-3 rounded-lg px-3 py-1.5">
          <div>
            <div className="text-[9px] uppercase tracking-wide text-slate-500">
              Total cost of delays this year
            </div>
            <div className="mono text-lg font-bold leading-none text-red-400">
              {fmtSEK(ytdDisplay)} SEK
            </div>
          </div>
          <div className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-red-400">
            ↑ 12% vs last month
          </div>
        </div>

        <KPI label="Patients waiting" value={fmtNum(totalPatients)} color="#36e0f1" />
        <KPI label="Monthly burn" value={fmtSEK(totalMonthlyCost) + " SEK"} color="#ffcb47" />
        <KPI label="Turbulence zones" value={`${turbCount}`} color="#ff4d5e" />
        <KPI label="Avg vs guarantee" value={`${Math.round(avgRatio * 100)}%`} color="#a78bfa" />

        {/* Mode toggle */}
        <div className="ml-auto flex items-center gap-1 rounded-lg border border-white/10 bg-black/30 p-0.5">
          <ModeBtn active={costMode} onClick={() => setCostMode(true)} label="💰 Cost Mode" />
          <ModeBtn active={!costMode} onClick={() => setCostMode(false)} label="👤 Patient Mode" />
        </div>
      </header>

      {/* ===== Main grid ===== */}
      <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 p-2 lg:grid-cols-[260px_1fr_320px]">
        {/* Filters */}
        <aside className="hidden min-h-0 lg:block">
          <Filters filters={filters} setFilters={setFilters} costMode={costMode} maxCost={maxCost} />
        </aside>

        {/* Radar */}
        <main className="glass relative min-h-0 overflow-hidden rounded-xl">
          <div className="absolute left-3 top-3 z-20 text-[10px] uppercase tracking-widest text-cyan-400/70 mono">
            ▸ {costMode ? "COST MODE" : "PATIENT MODE"} · LIVE SWEEP
          </div>
          <RadarMap
            delays={visible}
            selectedId={selectedId}
            hoveredId={hoveredId}
            costMode={costMode}
            showTurbulence={filters.showTurbulence}
            onSelect={setSelectedId}
            onHover={setHoveredId}
          />
        </main>

        {/* Data card */}
        <aside className="min-h-0">
          <DataCard delay={selected} onClose={() => setSelectedId(null)} />
        </aside>
      </div>

      {/* ===== Timeline scrubber ===== */}
      <footer className="border-t border-cyan-500/15 bg-black/40 px-4 py-2.5">
        <div className="flex items-center gap-3">
          <button
            onClick={handlePlay}
            className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-cyan-400/40 bg-cyan-400/10 text-cyan-300 transition hover:bg-cyan-400/20"
          >
            {playing ? "⏸" : "▶"}
          </button>

          <div className="flex-1">
            <div className="mb-1 flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-widest text-slate-500">
                Timeline · 24-month replay
              </span>
              <span className="mono text-xs font-semibold text-cyan-300">
                {MONTH_LABELS[monthIndex]}
                {monthIndex === 23 && <span className="ml-1.5 text-red-400 blink">● LIVE</span>}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={23}
              step={1}
              value={monthIndex}
              onChange={(e) => {
                setPlaying(false);
                setMonthIndex(+e.target.value);
              }}
              className="scrubber w-full"
            />
            <div className="mt-1 flex justify-between text-[9px] text-slate-600 mono">
              <span>{MONTH_LABELS[0]}</span>
              <span>{MONTH_LABELS[11]}</span>
              <span>{MONTH_LABELS[23]} (now)</span>
            </div>
          </div>

          {/* live cost meter */}
          <div className="hidden flex-shrink-0 text-right sm:block">
            <div className="text-[9px] uppercase tracking-wide text-slate-500">Cost meter (annualized)</div>
            <div className="mono text-base font-bold text-amber-400">
              {fmtSEK(ytdDisplay)} SEK
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function KPI({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="glass-soft hidden rounded-lg px-3 py-1.5 md:block">
      <div className="text-[9px] uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mono text-sm font-bold leading-tight" style={{ color }}>
        {value}
      </div>
    </div>
  );
}

function ModeBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className="rounded-md px-2.5 py-1 text-xs font-semibold transition"
      style={{
        background: active ? "rgba(54,224,241,0.18)" : "transparent",
        color: active ? "#7fe9f5" : "#94a3b8",
      }}
    >
      {label}
    </button>
  );
}
