import { useMemo } from "react";
import {
  type Delay,
  guaranteeRatio,
  isTurbulence,
  monthlyCost,
} from "./data";
import { project, swedenPath, islandPaths, VIEW_W, VIEW_H } from "./sweden";

interface Props {
  delays: Delay[];
  selectedId: string | null;
  hoveredId: string | null;
  costMode: boolean;
  showTurbulence: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
}

// Color by severity (guarantee ratio)
function severityColor(ratio: number): string {
  if (ratio >= 1.5) return "#ff4d5e";
  if (ratio >= 1.2) return "#ffcb47";
  if (ratio > 1.0) return "#36e0f1";
  return "#36f1a8";
}

// Plane icon rotated by a bearing derived from id for variety
function planeRotation(d: Delay): number {
  const seed = d.id.charCodeAt(2) + d.id.charCodeAt(3) + d.patientsInQueue;
  return (seed % 360);
}

export default function RadarMap({
  delays,
  selectedId,
  hoveredId,
  costMode,
  showTurbulence,
  onSelect,
  onHover,
}: Props) {
  const path = useMemo(() => swedenPath(), []);
  const islands = useMemo(() => islandPaths(), []);

  // Range scaling for "altitude" indicator size
  const maxMetric = useMemo(() => {
    return Math.max(
      ...delays.map((d) => (costMode ? monthlyCost(d) : d.patientsInQueue)),
      1
    );
  }, [delays, costMode]);

  return (
    <div className="relative h-full w-full overflow-hidden">
      <svg
        viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
        className="relative z-10 h-full w-full"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          <radialGradient id="mapGlow" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor="rgba(54,224,241,0.10)" />
            <stop offset="100%" stopColor="rgba(54,224,241,0)" />
          </radialGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Grid graticule */}
        <g stroke="rgba(54,224,241,0.07)" strokeWidth="0.5">
          {Array.from({ length: 9 }).map((_, i) => (
            <line key={"h" + i} x1={0} y1={(VIEW_H / 9) * i} x2={VIEW_W} y2={(VIEW_H / 9) * i} />
          ))}
          {Array.from({ length: 6 }).map((_, i) => (
            <line key={"v" + i} x1={(VIEW_W / 6) * i} y1={0} x2={(VIEW_W / 6) * i} y2={VIEW_H} />
          ))}
        </g>

        <rect x={0} y={0} width={VIEW_W} height={VIEW_H} fill="url(#mapGlow)" />

        {/* Rotating radar sweep beam */}
        <g style={{ transformOrigin: `${VIEW_W / 2}px ${VIEW_H / 2}px` }} className="radar-sweep">
          <defs>
            <linearGradient id="sweepGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="rgba(54,224,241,0.28)" />
              <stop offset="100%" stopColor="rgba(54,224,241,0)" />
            </linearGradient>
          </defs>
          <polygon
            points={`${VIEW_W / 2},${VIEW_H / 2} ${VIEW_W},${VIEW_H / 2 - 120} ${VIEW_W},${VIEW_H / 2 + 40}`}
            fill="url(#sweepGrad)"
          />
          <line
            x1={VIEW_W / 2}
            y1={VIEW_H / 2}
            x2={VIEW_W}
            y2={VIEW_H / 2}
            stroke="rgba(54,224,241,0.5)"
            strokeWidth="1"
          />
        </g>
        {/* concentric range rings */}
        {[120, 240, 360].map((r) => (
          <circle
            key={r}
            cx={VIEW_W / 2}
            cy={VIEW_H / 2}
            r={r}
            fill="none"
            stroke="rgba(54,224,241,0.06)"
            strokeWidth="0.6"
          />
        ))}

        {/* Sweden landmass */}
        <path
          d={path}
          fill="rgba(20,40,55,0.55)"
          stroke="rgba(54,224,241,0.55)"
          strokeWidth="1.2"
        />
        {islands.map((p, i) => (
          <path key={i} d={p} fill="rgba(20,40,55,0.55)" stroke="rgba(54,224,241,0.4)" strokeWidth="0.8" />
        ))}

        {/* Turbulence zones */}
        {showTurbulence &&
          delays.filter(isTurbulence).map((d) => {
            const { x, y } = project(d.lon, d.lat);
            return (
              <g key={"turb" + d.id} className="pointer-events-none">
                <circle cx={x} cy={y} r={26} fill="rgba(255,77,94,0.06)" stroke="rgba(255,77,94,0.35)" strokeWidth="0.8" strokeDasharray="3 3" />
                <circle cx={x} cy={y} r={18} fill="none" stroke="rgba(255,77,94,0.5)" strokeWidth="0.6" strokeDasharray="2 4" />
              </g>
            );
          })}

        {/* Flights */}
        {delays.map((d) => {
          const { x, y } = project(d.lon, d.lat);
          const ratio = guaranteeRatio(d);
          const color = severityColor(ratio);
          const active = selectedId === d.id || hoveredId === d.id;
          const metric = costMode ? monthlyCost(d) : d.patientsInQueue;
          const size = 5 + (metric / maxMetric) * 9; // "altitude" -> dot size
          const rot = planeRotation(d);
          // trail length scaled by persistence
          const trailLen = 8 + d.monthsPersisted * 1.6;
          const rad = (rot * Math.PI) / 180;
          const tx = x - Math.cos(rad) * trailLen;
          const ty = y - Math.sin(rad) * trailLen;

          return (
            <g
              key={d.id}
              className="cursor-pointer"
              onClick={() => onSelect(d.id)}
              onMouseEnter={() => onHover(d.id)}
              onMouseLeave={() => onHover(null)}
            >
              {/* trail */}
              <line
                x1={tx}
                y1={ty}
                x2={x}
                y2={y}
                stroke={color}
                strokeWidth={active ? 2 : 1.2}
                strokeLinecap="round"
                opacity={active ? 0.85 : 0.45}
              />
              {/* speed pulse for fast-growing queues */}
              {d.queueGrowthPerWeek > 20 && (
                <circle cx={x} cy={y} r={size + 4} fill="none" stroke={color} strokeWidth="0.8" opacity={0.4} className="blink" />
              )}
              {/* selection ring */}
              {active && (
                <circle cx={x} cy={y} r={size + 7} fill="none" stroke={color} strokeWidth="1.2" opacity={0.9} />
              )}
              {/* plane glyph */}
              <g transform={`translate(${x},${y}) rotate(${rot})`} filter="url(#glow)">
                <path
                  d="M8,0 L-4,-4 L-2,0 L-4,4 Z"
                  fill={color}
                  transform={`scale(${0.5 + size / 14})`}
                />
              </g>
              {/* hit area */}
              <circle cx={x} cy={y} r={14} fill="transparent" />
              {/* label on active */}
              {active && (
                <g className="pointer-events-none">
                  <rect x={x + 10} y={y - 16} width={d.city.length * 6.2 + 12} height={16} rx={3} fill="rgba(4,7,13,0.85)" stroke={color} strokeWidth="0.5" />
                  <text x={x + 16} y={y - 4} fontSize="9" className="mono" fill={color}>
                    {d.city} · {d.id}
                  </text>
                </g>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="glass-soft pointer-events-none absolute bottom-3 left-3 z-20 rounded-lg px-3 py-2 text-[10px] text-slate-300">
        <div className="mb-1 font-semibold tracking-wide text-slate-400">SEVERITY (vs vårdgaranti)</div>
        <div className="flex flex-col gap-0.5">
          <LegendRow color="#36f1a8" label="≤ 100% (within guarantee)" />
          <LegendRow color="#36e0f1" label="100–120%" />
          <LegendRow color="#ffcb47" label="120–150%" />
          <LegendRow color="#ff4d5e" label="≥ 150% — turbulence" />
        </div>
      </div>

      {/* Compass */}
      <div className="pointer-events-none absolute right-3 top-3 z-20 text-[10px] text-cyan-400/70 mono">
        N ▲ · {delays.length} TRACKS
      </div>
    </div>
  );
}

function LegendRow({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="inline-block h-2 w-2 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
      <span>{label}</span>
    </div>
  );
}
