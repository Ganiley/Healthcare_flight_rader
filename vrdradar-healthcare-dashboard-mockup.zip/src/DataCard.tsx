import {
  type Delay,
  costBreakdown,
  monthlyCost,
  daysOverTarget,
  guaranteeRatio,
  isTurbulence,
  fmtSEK,
  fmtNum,
} from "./data";

interface Props {
  delay: Delay | null;
  onClose: () => void;
}

const causeColor: Record<string, string> = {
  "OR capacity": "#ff4d5e",
  "Specialist shortage": "#ffcb47",
  "Admin backlog": "#36e0f1",
  "Bed shortage": "#a78bfa",
  "Diagnostics backlog": "#36f1a8",
};

export default function DataCard({ delay, onClose }: Props) {
  if (!delay) {
    return (
      <div className="glass flex h-full flex-col items-center justify-center rounded-xl p-6 text-center">
        <div className="mb-3 text-4xl">🛰️</div>
        <div className="text-sm font-semibold text-slate-300">No track selected</div>
        <p className="mt-1 max-w-[220px] text-xs text-slate-500">
          Click a flight on the radar to inspect its delay, queue and societal cost breakdown.
        </p>
      </div>
    );
  }

  const d = delay;
  const cost = monthlyCost(d);
  const bd = costBreakdown(d);
  const over = daysOverTarget(d);
  const ratio = guaranteeRatio(d);
  const turb = isTurbulence(d);
  const accent = ratio >= 1.5 ? "#ff4d5e" : ratio >= 1.2 ? "#ffcb47" : "#36e0f1";

  return (
    <div className="glass flex h-full flex-col overflow-hidden rounded-xl">
      {/* header */}
      <div className="relative px-4 pt-4 pb-3" style={{ borderBottom: `1px solid ${accent}33` }}>
        <button
          onClick={onClose}
          className="absolute right-3 top-3 rounded-md px-1.5 text-slate-500 hover:text-slate-200"
        >
          ✕
        </button>
        <div className="flex items-center gap-2">
          <span className="mono rounded bg-black/40 px-1.5 py-0.5 text-[10px]" style={{ color: accent }}>
            {d.id}
          </span>
          {turb && (
            <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-red-400 blink">
              ⚠ TURBULENCE
            </span>
          )}
        </div>
        <h2 className="mt-2 text-base font-bold leading-tight text-white">
          {d.patientGroup}
        </h2>
        <div className="text-xs text-slate-400">
          {d.specialty} · {d.region} ({d.city})
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3">
        {/* wait time gauge */}
        <div className="mb-4">
          <div className="mb-1 flex items-end justify-between">
            <span className="text-[11px] uppercase tracking-wide text-slate-500">Current wait</span>
            <span className="mono text-xs text-slate-400">target {d.guaranteeDays}d</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="mono text-3xl font-bold" style={{ color: accent }}>
              {d.currentWaitDays}
            </span>
            <span className="text-sm text-slate-400">days</span>
            <span className="mono ml-auto text-xs" style={{ color: accent }}>
              {Math.round(ratio * 100)}% of guarantee
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-black/40">
            <div
              className="h-full rounded-full"
              style={{
                width: `${Math.min(100, (ratio / 2) * 100)}%`,
                background: `linear-gradient(90deg, #36f1a8, ${accent})`,
              }}
            />
          </div>
          <div className="mono mt-1 text-[11px] text-slate-500">
            {over} days over vårdgaranti target
          </div>
        </div>

        {/* key stats */}
        <div className="mb-4 grid grid-cols-2 gap-2">
          <Stat label="Patients in queue" value={fmtNum(d.patientsInQueue)} accent="#36e0f1" />
          <Stat label="Queue growth" value={`+${d.queueGrowthPerWeek}/wk`} accent="#ffcb47" />
          <Stat label="Persisted" value={`${d.monthsPersisted} mo`} accent="#a78bfa" />
          <Stat
            label="Care daily cost"
            value={`${fmtNum(d.careType === "surgical" ? 2400 : 1200)} SEK`}
            accent="#36f1a8"
          />
        </div>

        {/* cost */}
        <div className="rounded-lg border border-white/5 bg-black/30 p-3">
          <div className="text-[11px] uppercase tracking-wide text-slate-500">
            Estimated societal cost
          </div>
          <div className="mono mt-0.5 text-2xl font-bold text-white">
            {fmtSEK(cost)} <span className="text-sm font-normal text-slate-400">SEK/month</span>
          </div>

          <div className="mt-3 space-y-2">
            <CostRow label="Lost productivity" value={bd.lostProductivity} total={cost} color="#ff4d5e" />
            <CostRow label="Overtime staffing" value={bd.overtimeStaffing} total={cost} color="#ffcb47" />
            <CostRow label="Penalty fees" value={bd.penaltyFees} total={cost} color="#36e0f1" />
          </div>
          <div className="mono mt-3 border-t border-white/5 pt-2 text-[10px] text-slate-500">
            = {fmtNum(d.patientsInQueue)} pts × {over} days over × {fmtNum(d.careType === "surgical" ? 2400 : 1200)} SEK ÷ 30
          </div>
        </div>

        {/* cause */}
        <div className="mt-4">
          <div className="text-[11px] uppercase tracking-wide text-slate-500">Bottleneck cause</div>
          <div
            className="mt-1 inline-flex items-center gap-2 rounded-md px-2.5 py-1 text-sm font-semibold"
            style={{ background: `${causeColor[d.cause]}1a`, color: causeColor[d.cause] }}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: causeColor[d.cause] }} />
            {d.cause}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent: string }) {
  return (
    <div className="rounded-lg border border-white/5 bg-black/20 p-2">
      <div className="text-[10px] uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mono mt-0.5 text-sm font-bold" style={{ color: accent }}>
        {value}
      </div>
    </div>
  );
}

function CostRow({
  label,
  value,
  total,
  color,
}: {
  label: string;
  value: number;
  total: number;
  color: string;
}) {
  const pct = total > 0 ? (value / total) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-300">{label}</span>
        <span className="mono text-slate-400">{fmtSEK(value)} SEK</span>
      </div>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-black/40">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
