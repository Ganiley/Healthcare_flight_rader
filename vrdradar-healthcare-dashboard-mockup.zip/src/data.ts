// VårdRadar simulated dataset — realistic but fake Swedish healthcare bottleneck data.
// Wait times loosely modeled on Socialstyrelsen / SKR vårdgaranti reporting.

export type Cause = "OR capacity" | "Specialist shortage" | "Admin backlog" | "Bed shortage" | "Diagnostics backlog";
export type CareType = "surgical" | "specialist";

export interface CostBreakdown {
  lostProductivity: number; // SEK / month
  overtimeStaffing: number; // SEK / month
  penaltyFees: number; // SEK / month
}

export interface Delay {
  id: string;
  patientGroup: string; // e.g. "Hip replacement"
  specialty: string;
  region: string; // Swedish region (län/region)
  city: string;
  // Geographic location (real lat/lon of the hospital city)
  lat: number;
  lon: number;
  careType: CareType;
  guaranteeDays: number; // vårdgaranti target
  currentWaitDays: number; // current median wait
  patientsInQueue: number;
  queueGrowthPerWeek: number; // new patients added net / week -> "speed"
  monthsPersisted: number; // how long bottleneck has persisted -> "trail"
  cause: Cause;
}

export const DAILY_COST: Record<CareType, number> = {
  surgical: 2400,
  specialist: 1200,
};

// Sweden approximate bounding box for projection
export const SWEDEN_BOUNDS = {
  minLat: 55.2,
  maxLat: 69.1,
  minLon: 10.9,
  maxLon: 24.2,
};

export const DELAYS: Delay[] = [
  {
    id: "VR101",
    patientGroup: "Hip replacement",
    specialty: "Orthopedics",
    region: "Västra Götaland",
    city: "Göteborg",
    lat: 57.7089,
    lon: 11.9746,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 187,
    patientsInQueue: 1240,
    queueGrowthPerWeek: 34,
    monthsPersisted: 19,
    cause: "OR capacity",
  },
  {
    id: "VR102",
    patientGroup: "Cataract surgery",
    specialty: "Ophthalmology",
    region: "Stockholm",
    city: "Stockholm",
    lat: 59.3293,
    lon: 18.0686,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 142,
    patientsInQueue: 2180,
    queueGrowthPerWeek: 41,
    monthsPersisted: 14,
    cause: "OR capacity",
  },
  {
    id: "VR103",
    patientGroup: "Knee replacement",
    specialty: "Orthopedics",
    region: "Skåne",
    city: "Malmö",
    lat: 55.605,
    lon: 13.0038,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 211,
    patientsInQueue: 980,
    queueGrowthPerWeek: 22,
    monthsPersisted: 22,
    cause: "OR capacity",
  },
  {
    id: "VR104",
    patientGroup: "ADHD assessment (adult)",
    specialty: "Psychiatry",
    region: "Stockholm",
    city: "Stockholm",
    lat: 59.3326,
    lon: 18.0649,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 364,
    patientsInQueue: 3400,
    queueGrowthPerWeek: 58,
    monthsPersisted: 24,
    cause: "Specialist shortage",
  },
  {
    id: "VR105",
    patientGroup: "Bariatric surgery",
    specialty: "Surgery",
    region: "Östergötland",
    city: "Linköping",
    lat: 58.4109,
    lon: 15.6216,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 168,
    patientsInQueue: 540,
    queueGrowthPerWeek: 11,
    monthsPersisted: 12,
    cause: "OR capacity",
  },
  {
    id: "VR106",
    patientGroup: "Colonoscopy",
    specialty: "Gastroenterology",
    region: "Uppsala",
    city: "Uppsala",
    lat: 59.8586,
    lon: 17.6389,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 121,
    patientsInQueue: 760,
    queueGrowthPerWeek: 18,
    monthsPersisted: 9,
    cause: "Diagnostics backlog",
  },
  {
    id: "VR107",
    patientGroup: "Spinal surgery",
    specialty: "Neurosurgery",
    region: "Västerbotten",
    city: "Umeå",
    lat: 63.8258,
    lon: 20.263,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 238,
    patientsInQueue: 310,
    queueGrowthPerWeek: 7,
    monthsPersisted: 20,
    cause: "Specialist shortage",
  },
  {
    id: "VR108",
    patientGroup: "Hearing aid fitting",
    specialty: "Audiology",
    region: "Norrbotten",
    city: "Luleå",
    lat: 65.5848,
    lon: 22.1547,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 156,
    patientsInQueue: 420,
    queueGrowthPerWeek: 9,
    monthsPersisted: 15,
    cause: "Admin backlog",
  },
  {
    id: "VR109",
    patientGroup: "MRI knee diagnostics",
    specialty: "Radiology",
    region: "Halland",
    city: "Halmstad",
    lat: 56.6745,
    lon: 12.8568,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 98,
    patientsInQueue: 640,
    queueGrowthPerWeek: 15,
    monthsPersisted: 7,
    cause: "Diagnostics backlog",
  },
  {
    id: "VR110",
    patientGroup: "Hernia repair",
    specialty: "Surgery",
    region: "Jönköping",
    city: "Jönköping",
    lat: 57.7826,
    lon: 14.1618,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 133,
    patientsInQueue: 480,
    queueGrowthPerWeek: 12,
    monthsPersisted: 10,
    cause: "Bed shortage",
  },
  {
    id: "VR111",
    patientGroup: "Heart valve surgery",
    specialty: "Cardiology",
    region: "Skåne",
    city: "Lund",
    lat: 55.7047,
    lon: 13.191,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 119,
    patientsInQueue: 215,
    queueGrowthPerWeek: 5,
    monthsPersisted: 11,
    cause: "Bed shortage",
  },
  {
    id: "VR112",
    patientGroup: "Autism assessment (child)",
    specialty: "Pediatric psychiatry",
    region: "Västra Götaland",
    city: "Borås",
    lat: 57.721,
    lon: 12.9401,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 295,
    patientsInQueue: 1120,
    queueGrowthPerWeek: 27,
    monthsPersisted: 23,
    cause: "Specialist shortage",
  },
  {
    id: "VR113",
    patientGroup: "Shoulder arthroscopy",
    specialty: "Orthopedics",
    region: "Dalarna",
    city: "Falun",
    lat: 60.6065,
    lon: 15.6355,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 174,
    patientsInQueue: 360,
    queueGrowthPerWeek: 8,
    monthsPersisted: 16,
    cause: "OR capacity",
  },
  {
    id: "VR114",
    patientGroup: "Skin cancer excision",
    specialty: "Dermatology",
    region: "Gävleborg",
    city: "Gävle",
    lat: 60.6749,
    lon: 17.1413,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 107,
    patientsInQueue: 290,
    queueGrowthPerWeek: 10,
    monthsPersisted: 8,
    cause: "Diagnostics backlog",
  },
  {
    id: "VR115",
    patientGroup: "Urology consultation",
    specialty: "Urology",
    region: "Örebro",
    city: "Örebro",
    lat: 59.2741,
    lon: 15.2066,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 138,
    patientsInQueue: 510,
    queueGrowthPerWeek: 13,
    monthsPersisted: 12,
    cause: "Admin backlog",
  },
  {
    id: "VR116",
    patientGroup: "Endometriosis surgery",
    specialty: "Gynecology",
    region: "Västernorrland",
    city: "Sundsvall",
    lat: 62.3908,
    lon: 17.3069,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 202,
    patientsInQueue: 275,
    queueGrowthPerWeek: 6,
    monthsPersisted: 18,
    cause: "Specialist shortage",
  },
  {
    id: "VR117",
    patientGroup: "Cardiology consultation",
    specialty: "Cardiology",
    region: "Värmland",
    city: "Karlstad",
    lat: 59.3793,
    lon: 13.5036,
    careType: "specialist",
    guaranteeDays: 90,
    currentWaitDays: 111,
    patientsInQueue: 430,
    queueGrowthPerWeek: 14,
    monthsPersisted: 9,
    cause: "Admin backlog",
  },
  {
    id: "VR118",
    patientGroup: "Prostate surgery",
    specialty: "Urology",
    region: "Kalmar",
    city: "Kalmar",
    lat: 56.6634,
    lon: 16.3566,
    careType: "surgical",
    guaranteeDays: 90,
    currentWaitDays: 159,
    patientsInQueue: 230,
    queueGrowthPerWeek: 5,
    monthsPersisted: 13,
    cause: "OR capacity",
  },
];

// ---- Derived calculations ----

export function daysOverTarget(d: Delay): number {
  return Math.max(0, d.currentWaitDays - d.guaranteeDays);
}

// Cost = Patients_waiting × Avg_days_over_target × Daily_societal_cost_SEK (per month basis)
// We treat the figure as a monthly societal cost estimate.
export function monthlyCost(d: Delay): number {
  return d.patientsInQueue * daysOverTarget(d) * DAILY_COST[d.careType] / 30;
}

export function costBreakdown(d: Delay): CostBreakdown {
  const total = monthlyCost(d);
  return {
    lostProductivity: total * 0.58,
    overtimeStaffing: total * 0.29,
    penaltyFees: total * 0.13,
  };
}

// vårdgaranti exceedance ratio
export function guaranteeRatio(d: Delay): number {
  return d.currentWaitDays / d.guaranteeDays;
}

export function isTurbulence(d: Delay): boolean {
  return guaranteeRatio(d) >= 1.5;
}

// Timeline: reconstruct a delay's historical state at a given month index (0..23)
// monthIndex 23 = present. Earlier months scale down based on persistence + growth.
export function delayAtMonth(d: Delay, monthIndex: number): Delay {
  const monthsAgo = 23 - monthIndex;
  // If bottleneck hadn't started yet, return near-baseline (at guarantee).
  if (monthsAgo >= d.monthsPersisted) {
    return {
      ...d,
      currentWaitDays: d.guaranteeDays,
      patientsInQueue: Math.round(d.patientsInQueue * 0.12),
    };
  }
  const progress = 1 - monthsAgo / d.monthsPersisted; // 0 at start -> 1 now
  const eased = Math.pow(progress, 0.85);
  const baseWait = d.guaranteeDays;
  const wait = Math.round(baseWait + (d.currentWaitDays - baseWait) * eased);
  const queue = Math.round(d.patientsInQueue * (0.2 + 0.8 * eased));
  return { ...d, currentWaitDays: wait, patientsInQueue: queue };
}

export const REGIONS = Array.from(new Set(DELAYS.map((d) => d.region))).sort();
export const SPECIALTIES = Array.from(new Set(DELAYS.map((d) => d.specialty))).sort();
export const CAUSES: Cause[] = [
  "OR capacity",
  "Specialist shortage",
  "Admin backlog",
  "Bed shortage",
  "Diagnostics backlog",
];

export function fmtSEK(v: number): string {
  if (v >= 1e9) return (v / 1e9).toFixed(2) + "B";
  if (v >= 1e6) return (v / 1e6).toFixed(1) + "M";
  if (v >= 1e3) return (v / 1e3).toFixed(0) + "k";
  return Math.round(v).toString();
}

export function fmtNum(v: number): string {
  return Math.round(v).toLocaleString("sv-SE");
}
